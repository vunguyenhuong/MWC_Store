package application;

import views.SplashScreen;

/**
 *
 * @author VU NGUYEN HUONG
 */
public class Application {

    public static void main(String[] args) {
        System.out.println("kimchicute");
        new SplashScreen().setVisible(true);
    }
}

