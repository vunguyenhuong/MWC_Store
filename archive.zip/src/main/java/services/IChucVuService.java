package services;

import java.util.List;
import models.ChucVu;

/**
 *
 * @author VU NGUYEN HUONG
 */
public interface IChucVuService {
    List<ChucVu> getAll();
}
