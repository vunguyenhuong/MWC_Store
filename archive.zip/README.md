# MWC_Store

Man Women And Choices.

## Thành viên trong nhóm

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

Vũ Nguyên Hướng - PH27229

Lại Thị Kim Chi - PH26384

Dương Văn Cảnh - PH23043

Hoàng Vĩnh Giang

Đặng Thanh Phương

Cao Văn Doanh

## Usage

```python
import foobar

# returns 'words'
foobar.pluralize('word')

# returns 'geese'
foobar.pluralize('goose')

# returns 'phenomenon'
foobar.singularize('phenomena')
```

## Contributing

Pull requests are welcome. For major changes, please open an issue first
to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License

[MIT](https://choosealicense.com/licenses/mit/)
